CREATE TABLE IF NOT EXISTS unit_notes (
	 id TEXT PRIMARY KEY NOT NULL,
	 nickname TEXT NOT NULL,
	 caption TEXT NOT NULL DEFAULT '',
	 level TEXT NOT NULL,
	 course TEXT NOT NULL,
	 unit TEXT NOT NULL,
	 image_key TEXT NOT NULL,
	 image_type TEXT NOT NULL,
	 created_at TEXT NOT NULL
);
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS idx_unit_notes_course_unit_created
	ON unit_notes (course, unit, created_at DESC);
