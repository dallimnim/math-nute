import { readFile, writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const path = resolve(root, "index.html");
let html = await readFile(path, "utf8");
const heading = /(<section class="panel daily-box"><h2>)[\s\S]*?(<\/h2><p class="hint">)[\s\S]*?(<\/p>)/;
if (!heading.test(html)) throw new Error("오늘의 단원 선택 문구를 찾을 수 없습니다.");
html = html.replace(heading, `$1어디까지 공부하였나요?$2단원을 선택하면 그 단원까지 누적테스트 문제가 랜덤하게 나옵니다.$3`);
await writeFile(path, html, "utf8");
