import { readFile, writeFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const [template, html] = await Promise.all([
  readFile(resolve(root, "worker/index.template.js"), "utf8"),
  readFile(resolve(root, "index.html"), "utf8"),
]);
const marker = '"__PAGE_BASE64__"';
if (!template.includes(marker)) throw new Error("Worker page marker is missing");
const encoded = Buffer.from(html, "utf8").toString("base64");
await writeFile(resolve(root, "worker/index.js"), template.replace(marker, JSON.stringify(encoded)), "utf8");
