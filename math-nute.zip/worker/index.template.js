const pageBase64 = "__PAGE_BASE64__";
const PAGE = new TextDecoder().decode(
  Uint8Array.from(atob(pageBase64), (character) => character.charCodeAt(0)),
);

const JSON_HEADERS = { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" };
const MAX_IMAGE_BYTES = 3.5 * 1024 * 1024;

function json(data, status = 200) {
  return new Response(JSON.stringify(data), { status, headers: JSON_HEADERS });
}

function validUnit(level, course, unit) {
  return [level, course, unit].every((value) => typeof value === "string" && value.trim().length > 0 && value.length <= 100);
}

function imageMatchesType(bytes, type) {
  if (type === "image/png") return bytes.length > 8 && bytes[0] === 137 && bytes[1] === 80 && bytes[2] === 78 && bytes[3] === 71;
  if (type === "image/jpeg") return bytes.length > 3 && bytes[0] === 255 && bytes[1] === 216 && bytes[2] === 255;
  if (type === "image/webp") return bytes.length > 12 && String.fromCharCode(...bytes.slice(0, 4)) === "RIFF" && String.fromCharCode(...bytes.slice(8, 12)) === "WEBP";
  return false;
}

async function handleApi(request, env, url) {
  if (!env.DB || !env.BUCKET) return json({ error: "공유 노트 저장소가 아직 연결되지 않았습니다." }, 503);

  if (url.pathname === "/api/notes" && request.method === "GET") {
    const course = url.searchParams.get("course") || "";
    const unit = url.searchParams.get("unit") || "";
    if (!course || !unit || course.length > 100 || unit.length > 100) return json({ error: "단원 정보가 올바르지 않습니다." }, 400);
    const result = await env.DB.prepare(
      "SELECT id, nickname, caption, level, course, unit, created_at AS createdAt FROM unit_notes WHERE course = ? AND unit = ? ORDER BY created_at DESC LIMIT 60",
    ).bind(course, unit).all();
    return json({ notes: (result.results || []).map((note) => ({ ...note, imageUrl: `/api/notes/${note.id}/image` })) });
  }

  const imageMatch = url.pathname.match(/^\/api\/notes\/([a-f0-9-]{36})\/image$/i);
  if (imageMatch && request.method === "GET") {
    const note = await env.DB.prepare("SELECT image_key, image_type FROM unit_notes WHERE id = ?").bind(imageMatch[1]).first();
    if (!note) return json({ error: "노트를 찾을 수 없습니다." }, 404);
    const object = await env.BUCKET.get(note.image_key);
    if (!object) return json({ error: "이미지를 찾을 수 없습니다." }, 404);
    return new Response(object.body, { headers: { "content-type": note.image_type, "cache-control": "public, max-age=3600", "x-content-type-options": "nosniff" } });
  }

  if (url.pathname === "/api/notes" && request.method === "POST") {
    const length = Number(request.headers.get("content-length") || 0);
    if (length > MAX_IMAGE_BYTES + 16 * 1024) return json({ error: "이미지는 3.5MB 이하로 올려 주세요." }, 413);
    let form;
    try { form = await request.formData(); } catch { return json({ error: "업로드 형식이 올바르지 않습니다." }, 400); }
    const image = form.get("image");
    const level = String(form.get("level") || "");
    const course = String(form.get("course") || "");
    const unit = String(form.get("unit") || "");
    const nickname = String(form.get("nickname") || "수학 친구").trim().slice(0, 20) || "수학 친구";
    const caption = String(form.get("caption") || "").trim().slice(0, 180);
    if (!(image instanceof File) || image.size < 1 || image.size > MAX_IMAGE_BYTES) return json({ error: "3.5MB 이하의 이미지 파일을 선택해 주세요." }, 400);
    if (!validUnit(level, course, unit)) return json({ error: "단원 정보가 올바르지 않습니다." }, 400);
    const bytes = new Uint8Array(await image.arrayBuffer());
    if (!imageMatchesType(bytes, image.type)) return json({ error: "JPG, PNG, WebP 이미지 파일만 올릴 수 있습니다." }, 415);

    const id = crypto.randomUUID();
    const imageKey = `unit-notes/${id}`;
    await env.BUCKET.put(imageKey, bytes, { httpMetadata: { contentType: image.type } });
    try {
      await env.DB.prepare(
        "INSERT INTO unit_notes (id, nickname, caption, level, course, unit, image_key, image_type, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
      ).bind(id, nickname, caption, level, course, unit, imageKey, image.type, new Date().toISOString()).run();
    } catch {
      await env.BUCKET.delete(imageKey);
      return json({ error: "노트를 저장하지 못했습니다. 잠시 후 다시 시도해 주세요." }, 500);
    }
    return json({ ok: true, id }, 201);
  }

  return json({ error: "요청한 기능을 찾을 수 없습니다." }, 404);
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    try {
      if (url.pathname.startsWith("/api/")) return await handleApi(request, env, url);
      if (request.method !== "GET" && request.method !== "HEAD") return new Response("Method not allowed", { status: 405 });
      if (url.pathname === "/" || url.pathname === "/index.html") {
        return new Response(request.method === "HEAD" ? null : PAGE, { headers: { "content-type": "text/html; charset=utf-8", "x-content-type-options": "nosniff" } });
      }
      return new Response("Not found", { status: 404 });
    } catch {
      return json({ error: "요청을 처리하지 못했습니다. 잠시 후 다시 시도해 주세요." }, 500);
    }
  },
};
